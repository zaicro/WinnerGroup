﻿Imports System.IO
Imports ConnectionProtectionLab.Core

Friend Module Program
    Public Function Main(args As String()) As Integer
        Try
            If args.Length = 0 Then
                Help()
                Return 0
            End If
            Select Case args(0).ToLowerInvariant()
                Case "protect"
                    Require(args, 3)
                    ConfigurationProtection.ProtectFile(args(1), ConfigurationProtection.ProviderFor(args(2)))
                    Console.WriteLine("Configuración protegida.")
                Case "read-check"
                    Require(args, 2)
                    Dim value = ConfigurationProtection.ReadFile(args(1), "DemoDb")
                    If String.IsNullOrWhiteSpace(value) Then Throw New InvalidOperationException("Conexión vacía.")
                    Console.WriteLine("Lectura correcta; no se muestra la conexión.")
                Case "unprotect-lab"
                    Require(args, 3)
                    If args(2) <> "--write-plaintext" Then Throw New ArgumentException("Falta --write-plaintext.")
                    ConfigurationProtection.UnprotectFile(args(1))
                    Console.WriteLine("ATENCIÓN: configuración guardada en texto claro.")
                Case "rsa-create"
                    Require(args, 1)
                    RsaKeys.Create()
                    Console.WriteLine("Clave RSA creada en el perfil del usuario actual.")
                Case "rsa-export-private"
                    Require(args, 3)
                    If args(2) <> "--allow-plaintext-private-key" Then Throw New ArgumentException("Falta autorización explícita para exportar clave privada en claro.")
                    RsaKeys.ExportPrivate(args(1))
                    Console.WriteLine("Clave PRIVADA exportada en XML SIN CIFRAR. Retírela de las carpetas de distribución.")
                Case "rsa-import-private"
                    Require(args, 2)
                    RsaKeys.ImportPrivate(args(1))
                    Console.WriteLine("Clave RSA importada en el perfil del usuario actual.")
                Case "self-test"
                    Require(args, 1)
                    SelfTests.Run()
                Case Else
                    Help()
                    Return 2
            End Select
            Return 0
        Catch ex As Exception
            ' No imprimir excepciones completas: podrían incluir XML con información sensible.
            Console.Error.WriteLine("Error: " & ex.GetType().Name & ". Revise argumentos, permisos, proveedor y perfil/clave. No se muestran secretos.")
            Return 1
        End Try
    End Function

    Private Sub Require(args As String(), count As Integer)
        If args.Length <> count Then Throw New ArgumentException("Cantidad incorrecta de argumentos.")
    End Sub

    Private Sub Help()
        Console.WriteLine("ConfigTool protect <archivo.exe.config> machine|user|rsa")
        Console.WriteLine("ConfigTool read-check <archivo.exe.config>")
        Console.WriteLine("ConfigTool rsa-create")
        Console.WriteLine("ConfigTool rsa-export-private <archivo.xml> --allow-plaintext-private-key")
        Console.WriteLine("ConfigTool rsa-import-private <archivo.xml>")
        Console.WriteLine("ConfigTool unprotect-lab <archivo.exe.config> --write-plaintext")
        Console.WriteLine("ConfigTool self-test")
        Console.WriteLine("Use rutas entre comillas. No pase contraseñas como argumentos.")
    End Sub
End Module
