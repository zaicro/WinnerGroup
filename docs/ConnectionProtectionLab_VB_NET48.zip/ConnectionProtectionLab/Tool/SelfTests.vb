﻿Imports System.IO
Imports System.Security.Cryptography
Imports System.Text
Imports System.Xml.Linq
Imports ConnectionProtectionLab.Core

Friend Module SelfTests
    Public Sub Run()
        Dim folder = Path.Combine(Path.GetTempPath(), "ConnectionProtectionLab-" & Guid.NewGuid().ToString("N"))
        Dim keyName = "ConnectionProtectionLab.Test." & Guid.NewGuid().ToString("N")
        Directory.CreateDirectory(folder)
        Dim keyCreated As Boolean = False
        Try
            RsaKeys.Create(keyName)
            keyCreated = True
            For Each mode In New String() {"machine", "user", "rsa"}
                Dim filePath = Path.Combine(folder, mode & ".config")
                WriteFixture(filePath, keyName)
                Dim provider = ConfigurationProtection.ProviderFor(mode)
                ConfigurationProtection.ProtectFile(filePath, provider)
                Assert(Not File.ReadAllText(filePath).Contains("SECRETO_PRUEBA"), mode & ": no texto claro")
                Assert(File.ReadAllText(filePath).Contains("CipherValue"), mode & ": existe cifrado")
                Assert(ConfigurationProtection.ReadFile(filePath, "DemoDb") = "Password=SECRETO_PRUEBA;", mode & ": round-trip")
                ConfigurationProtection.ProtectFile(filePath, provider)
                Assert(ConfigurationProtection.ReadFile(filePath, "DemoDb") = "Password=SECRETO_PRUEBA;", mode & ": repetición segura")
                Dim wrong = If(mode = "machine", ConfigurationProtection.UserProvider, ConfigurationProtection.MachineProvider)
                Dim rejected As Boolean = False
                Try
                    ConfigurationProtection.ProtectFile(filePath, wrong)
                Catch ex As InvalidOperationException
                    rejected = True
                End Try
                Assert(rejected, mode & ": impide cambio accidental")
                ConfigurationProtection.UnprotectFile(filePath)
                Assert(File.ReadAllText(filePath).Contains("SECRETO_PRUEBA"), mode & ": reversión solo laboratorio")
            Next
            Dim externalPath = Path.Combine(folder, "secret.bin")
            ExternalSecret.Save("SECRETO_PRUEBA", externalPath)
            Assert(ExternalSecret.Read(externalPath) = "SECRETO_PRUEBA", "Externo: round-trip")
            Assert(Not Encoding.UTF8.GetString(File.ReadAllBytes(externalPath)).Contains("SECRETO_PRUEBA"), "Externo: no texto claro")
            ExternalSecret.Save("NUEVO_SECRETO", externalPath)
            Assert(ExternalSecret.Read(externalPath) = "NUEVO_SECRETO", "Externo: reemplazo")
            File.WriteAllBytes(externalPath, New Byte() {1, 2, 3, 4})
            Dim corruptRejected As Boolean = False
            Try
                ExternalSecret.Read(externalPath)
            Catch ex As CryptographicException
                corruptRejected = True
            End Try
            Assert(corruptRejected, "Externo: rechaza archivo inválido")
            Console.WriteLine("PASS: todas las comprobaciones locales terminaron correctamente.")
        Finally
            If keyCreated Then RsaKeys.Provider(keyName).DeleteKey()
            Directory.Delete(folder, True)
        End Try
    End Sub

    Private Sub Assert(condition As Boolean, description As String)
        If Not condition Then Throw New InvalidOperationException("Fallo de prueba: " & description)
        Console.WriteLine("PASS: " & description)
    End Sub

    Private Sub WriteFixture(filePath As String, keyName As String)
        Dim dpapiType = "System.Configuration.DpapiProtectedConfigurationProvider, System.Configuration, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a"
        Dim rsaType = "System.Configuration.RsaProtectedConfigurationProvider, System.Configuration, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a"
        Dim doc As New XDocument(
            New XElement("configuration",
                New XElement("configProtectedData", New XElement("providers",
                    New XElement("add", New XAttribute("name", "LabDpapiMachine"), New XAttribute("type", dpapiType), New XAttribute("useMachineProtection", "true")),
                    New XElement("add", New XAttribute("name", "LabDpapiUser"), New XAttribute("type", dpapiType), New XAttribute("useMachineProtection", "false")),
                    New XElement("add", New XAttribute("name", "LabRsa"), New XAttribute("type", rsaType), New XAttribute("keyContainerName", keyName), New XAttribute("useMachineContainer", "false"), New XAttribute("useOAEP", "true")))),
                New XElement("connectionStrings", New XElement("clear"), New XElement("add", New XAttribute("name", "DemoDb"), New XAttribute("connectionString", "Password=SECRETO_PRUEBA;")))))
        doc.Save(filePath)
    End Sub
End Module
