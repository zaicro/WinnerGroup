﻿Imports System.Configuration
Imports System.Data.SqlClient
Imports System.Deployment.Application
Imports System.Drawing
Imports System.Windows.Forms
Imports ConnectionProtectionLab.Core

Public Class MainForm
    Inherits Form

    Private ReadOnly modes As New ComboBox With {.DropDownStyle = ComboBoxStyle.DropDownList, .Width = 600}
    Private ReadOnly input As New TextBox With {.Width = 760, .UseSystemPasswordChar = True}
    Private ReadOnly status As New TextBox With {.Multiline = True, .ReadOnly = True, .Width = 760, .Height = 150, .ScrollBars = ScrollBars.Vertical}

    Public Sub New()
        Text = "Laboratorio de protección de conexiones · VB.NET 4.8"
        ClientSize = New Size(810, 510)
        MinimumSize = New Size(830, 550)
        Dim panel As New FlowLayoutPanel With {.Dock = DockStyle.Fill, .FlowDirection = FlowDirection.TopDown,
            .WrapContents = False, .AutoScroll = True, .Padding = New Padding(18)}
        panel.Controls.Add(New Label With {.Text = "Usa datos ficticios. Este laboratorio no abre conexiones a una base de datos.", .AutoSize = True})
        modes.Items.AddRange(New Object() {"1. .config · DPAPI por equipo", "2. .config · DPAPI por usuario",
                                         "3. .config · RSA por usuario", "4. Archivo externo · DPAPI por usuario"})
        modes.SelectedIndex = 0
        panel.Controls.Add(modes)
        panel.Controls.Add(New Label With {.Text = "Solo para archivo externo: introduce la cadena que deseas guardar.", .AutoSize = True})
        input.Text = "Server=SERVIDOR_DE_PRUEBA;Database=DemoDb;User ID=usuario_demo;Password=CLAVE_FICTICIA;Persist Security Info=False;"
        panel.Controls.Add(input)
        Dim show As New CheckBox With {.Text = "Mostrar entrada (solo datos de prueba)", .AutoSize = True}
        AddHandler show.CheckedChanged, Sub() input.UseSystemPasswordChar = Not show.Checked
        panel.Controls.Add(show)
        AddButton(panel, "Proteger .exe.config / guardar archivo externo", AddressOf SaveSelected)
        AddButton(panel, "Leer conexión y verificar sin mostrar contraseña", AddressOf ReadSelected)
        AddButton(panel, "Ver ubicaciones", Sub() SetStatus("Config: " & AppDomain.CurrentDomain.SetupInformation.ConfigurationFile & Environment.NewLine &
                                                       "Externo: " & ExternalSecret.DefaultPath()))
        panel.Controls.Add(status)
        panel.Controls.Add(New Label With {.Text = "Para RSA: ejecuta ConfigTool.exe rsa-create antes de proteger. Consulta README.md.", .AutoSize = True})
        Controls.Add(panel)
        SetStatus("Selecciona una variante. Las opciones 1–3 protegen la conexión DemoDb del .exe.config; no usan el cuadro de entrada.")
    End Sub

    Private Sub AddButton(panel As FlowLayoutPanel, caption As String, action As Action)
        Dim button As New Button With {.Text = caption, .AutoSize = True, .Height = 32}
        AddHandler button.Click, Sub()
            Try
                action()
            Catch ex As Exception
                ' No mostrar ex.ToString ni valores de configuración: podrían contener secretos.
                SetStatus("No se completó la operación (" & ex.GetType().Name & ")." & Environment.NewLine &
                          "Comprueba el modo, permisos, clave RSA e identidad de Windows. Consulta el README.")
            End Try
        End Sub
        panel.Controls.Add(button)
    End Sub

    Private Sub SaveSelected()
        If modes.SelectedIndex = 3 Then
            ExternalSecret.Save(input.Text, ExternalSecret.DefaultPath())
            SetStatus("Archivo externo guardado con DPAPI CurrentUser. No se modificó el .exe.config.")
            Return
        End If
        If ApplicationDeployment.IsNetworkDeployed Then
            Throw New InvalidOperationException("Con ClickOnce use el archivo externo o publique RSA ya protegido.")
        End If
        Dim names = New String() {ConfigurationProtection.MachineProvider, ConfigurationProtection.UserProvider, ConfigurationProtection.RsaProvider}
        ConfigurationProtection.ProtectFile(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile, names(modes.SelectedIndex))
        ConfigurationManager.RefreshSection("connectionStrings")
        SetStatus("Sección protegida. Cierra y vuelve a abrir para comprobar la lectura tras reiniciar. Para cambiar de proveedor usa otra copia sin cifrar.")
    End Sub

    Private Sub ReadSelected()
        Dim secret As String
        If modes.SelectedIndex = 3 Then
            secret = ExternalSecret.Read(ExternalSecret.DefaultPath())
        Else
            ' Lectura habitual: el proveedor .NET realiza el descifrado automáticamente.
            ConfigurationManager.RefreshSection("connectionStrings")
            secret = ConfigurationManager.ConnectionStrings("DemoDb").ConnectionString
        End If
        Dim parsed As New SqlConnectionStringBuilder(secret)
        SetStatus("Lectura correcta. Cadena SQL Server válida: " & secret.Length.ToString() & " caracteres." & Environment.NewLine &
                  "Contraseña presente: " & (Not String.IsNullOrEmpty(parsed.Password)).ToString() & Environment.NewLine &
                  "No se muestra el secreto ni se intenta conectar. Leer no cifra una sección que todavía esté en claro.")
    End Sub

    Private Sub SetStatus(message As String)
        status.Text = message
    End Sub
End Class
