﻿Imports System.IO
Imports System.Security.Cryptography
Imports System.Text

Public Module ExternalSecret
    Public Function DefaultPath() As String
        Return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                            "ConnectionProtectionLab", "connection.dpapi")
    End Function

    Public Sub Save(secret As String, filePath As String)
        If String.IsNullOrWhiteSpace(secret) Then Throw New ArgumentException("La conexión está vacía.")
        Dim plain = Encoding.UTF8.GetBytes(secret)
        Dim tempPath As String = Nothing
        Try
            Dim encrypted = ProtectedData.Protect(plain, Nothing, DataProtectionScope.CurrentUser)
            Dim fullPath = Path.GetFullPath(filePath)
            Directory.CreateDirectory(Path.GetDirectoryName(fullPath))
            tempPath = fullPath & "." & Guid.NewGuid().ToString("N") & ".tmp"
            ' Solo se escribe el cifrado; nunca un archivo temporal con el texto claro.
            File.WriteAllBytes(tempPath, encrypted)
            If File.Exists(fullPath) Then
                File.Replace(tempPath, fullPath, Nothing)
            Else
                File.Move(tempPath, fullPath)
            End If
        Finally
            Array.Clear(plain, 0, plain.Length)
            If tempPath IsNot Nothing AndAlso File.Exists(tempPath) Then File.Delete(tempPath)
        End Try
    End Sub

    Public Function Read(filePath As String) As String
        Dim plain = ProtectedData.Unprotect(File.ReadAllBytes(filePath), Nothing, DataProtectionScope.CurrentUser)
        Try
            Return Encoding.UTF8.GetString(plain)
        Finally
            Array.Clear(plain, 0, plain.Length)
        End Try
    End Function
End Module
