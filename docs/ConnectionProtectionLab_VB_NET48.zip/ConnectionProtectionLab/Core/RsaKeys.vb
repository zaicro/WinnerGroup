﻿Imports System.Collections.Specialized
Imports System.Configuration
Imports System.IO
Imports System.Security.Cryptography

Public Module RsaKeys
    Public Const ContainerName As String = "ConnectionProtectionLab.Rsa.v1"

    Public Function Provider(Optional container As String = ContainerName) As RsaProtectedConfigurationProvider
        Dim settings As New NameValueCollection From {
            {"keyContainerName", container}, {"useMachineContainer", "false"}, {"useOAEP", "true"}}
        Dim result As New RsaProtectedConfigurationProvider()
        result.Initialize("LabRsa", settings)
        Return result
    End Function

    Private Function Exists(container As String) As Boolean
        Dim parameters As New CspParameters() With {
            .KeyContainerName = container, .Flags = CspProviderFlags.UseExistingKey}
        Try
            Using key As New RSACryptoServiceProvider(parameters)
                Return True
            End Using
        Catch ex As CryptographicException
            ' Un fallo de acceso también podría causar esta excepción. AddKey deberá fallar,
            ' no se intenta reemplazar ni eliminar una clave existente.
            Return False
        End Try
    End Function

    Public Sub Create(Optional container As String = ContainerName)
        If Exists(container) Then Throw New InvalidOperationException("Ya existe ese contenedor RSA. No se reemplaza.")
        Provider(container).AddKey(2048, True)
    End Sub

    Public Sub ExportPrivate(filePath As String)
        If Not Exists(ContainerName) Then Throw New InvalidOperationException("Primero cree o importe la clave RSA.")
        If File.Exists(filePath) Then Throw New IOException("El archivo de destino ya existe.")
        ' XML SIN CIFRAR que incluye la clave PRIVADA; solo para traslado controlado del laboratorio.
        Provider().ExportKey(Path.GetFullPath(filePath), True)
    End Sub

    Public Sub ImportPrivate(filePath As String)
        If Exists(ContainerName) Then Throw New InvalidOperationException("Ya existe ese contenedor RSA. No se reemplaza.")
        Dim xml = File.ReadAllText(filePath)
        If Not xml.Contains("<D>") Then Throw New ArgumentException("El archivo debe contener la clave privada RSA.")
        Provider().ImportKey(Path.GetFullPath(filePath), True)
    End Sub
End Module
