﻿Imports System.Configuration
Imports System.IO

Public Module ConfigurationProtection
    Public Const MachineProvider As String = "LabDpapiMachine"
    Public Const UserProvider As String = "LabDpapiUser"
    Public Const RsaProvider As String = "LabRsa"

    Public Function ProviderFor(mode As String) As String
        Select Case mode.ToLowerInvariant()
            Case "machine" : Return MachineProvider
            Case "user" : Return UserProvider
            Case "rsa" : Return RsaProvider
            Case Else : Throw New ArgumentException("Modo permitido: machine, user o rsa.")
        End Select
    End Function

    Private Function OpenFile(configPath As String) As Configuration
        If Not File.Exists(configPath) Then Throw New FileNotFoundException("No existe el archivo de configuración.")
        Dim map As New ExeConfigurationFileMap With {.ExeConfigFilename = Path.GetFullPath(configPath)}
        Return ConfigurationManager.OpenMappedExeConfiguration(map, ConfigurationUserLevel.None)
    End Function

    Public Sub ProtectFile(configPath As String, provider As String)
        Dim config = OpenFile(configPath)
        Dim section = config.ConnectionStrings
        If section.SectionInformation.IsProtected Then
            If section.SectionInformation.ProtectionProvider.Name <> provider Then
                Throw New InvalidOperationException("Ya está protegido con otro proveedor. Utilice otra copia de laboratorio.")
            End If
            Return
        End If
        If String.IsNullOrEmpty(section.SectionInformation.GetRawXml()) Then
            Throw New InvalidOperationException("Falta una sección connectionStrings local.")
        End If
        section.SectionInformation.ProtectSection(provider)
        section.SectionInformation.ForceSave = True
        config.Save(ConfigurationSaveMode.Modified)
    End Sub

    ' Solo laboratorio: esta operación vuelve a escribir secretos EN CLARO en disco.
    Public Sub UnprotectFile(configPath As String)
        Dim config = OpenFile(configPath)
        If Not config.ConnectionStrings.SectionInformation.IsProtected Then Return
        config.ConnectionStrings.SectionInformation.UnprotectSection()
        config.ConnectionStrings.SectionInformation.ForceSave = True
        config.Save(ConfigurationSaveMode.Modified)
    End Sub

    Public Function ReadFile(configPath As String, name As String) As String
        Dim item = OpenFile(configPath).ConnectionStrings.ConnectionStrings(name)
        If item Is Nothing Then Throw New ConfigurationErrorsException("No existe la conexión solicitada.")
        ' El proveedor de .NET descifra automáticamente, sin modificar el archivo.
        Return item.ConnectionString
    End Function
End Module
