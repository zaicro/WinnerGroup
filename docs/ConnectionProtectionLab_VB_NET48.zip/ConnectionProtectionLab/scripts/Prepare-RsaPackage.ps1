param([ValidateSet('Debug','Release')][string]$Configuration = 'Release')
$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot 'Build.ps1') -Configuration $Configuration
$projectRoot = Split-Path $PSScriptRoot -Parent
$binPath = Join-Path $projectRoot "bin\$Configuration"
$destination = Join-Path $projectRoot 'artifacts\RsaCopyPackage'
if (Test-Path $destination) { throw 'Ya existe artifacts\RsaCopyPackage. Muévela o elimínala tras revisar su contenido antes de preparar otra versión.' }
$stage = Join-Path $projectRoot ('artifacts\stage-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $stage -Force | Out-Null
try {
    foreach ($name in @('ConnectionProtectionDemo.exe','ConnectionProtectionDemo.exe.config','ConnectionProtection.Core.dll')) {
        Copy-Item (Join-Path $binPath $name) (Join-Path $stage $name)
    }
    # Se reutiliza el contenedor del usuario actual. Crear/importar la clave antes.
    & (Join-Path $binPath 'ConfigTool.exe') protect (Join-Path $stage 'ConnectionProtectionDemo.exe.config') rsa
    if ($LASTEXITCODE -ne 0) { throw 'No se pudo cifrar. Prepara primero la clave RSA bajo esta cuenta.' }
    & (Join-Path $binPath 'ConfigTool.exe') read-check (Join-Path $stage 'ConnectionProtectionDemo.exe.config')
    if ($LASTEXITCODE -ne 0) { throw 'Falló la lectura del paquete RSA.' }
    Move-Item $stage $destination
    Write-Host "Paquete para copia preparado en $destination. No incluye clave privada ni publicación ClickOnce."
} finally {
    if (Test-Path $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
}
