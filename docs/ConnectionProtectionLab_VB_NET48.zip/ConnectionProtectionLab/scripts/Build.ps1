param([ValidateSet('Debug','Release')][string]$Configuration = 'Release')
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
$msbuild = Get-Command MSBuild.exe -ErrorAction SilentlyContinue
if (-not $msbuild) {
    $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
    if (Test-Path $vswhere) {
        $found = & $vswhere -latest -requires Microsoft.Component.MSBuild -find 'MSBuild\**\Bin\MSBuild.exe' | Select-Object -First 1
        if ($found) { $msbuild = Get-Item $found }
    }
}
if (-not $msbuild) { throw 'Instala Visual Studio con desarrollo de escritorio .NET y el targeting pack 4.8, o usa Developer PowerShell.' }
$buildPath = if ($msbuild.Path) { $msbuild.Path } else { $msbuild.FullName }
& $buildPath (Join-Path $projectRoot 'ConnectionProtectionLab.sln') /t:Build /m /p:Configuration=$Configuration /p:Platform='Any CPU' /nologo
if ($LASTEXITCODE -ne 0) { throw 'Falló la compilación.' }
