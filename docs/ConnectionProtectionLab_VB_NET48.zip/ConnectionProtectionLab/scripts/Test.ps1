param([ValidateSet('Debug','Release')][string]$Configuration = 'Release')
$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot 'Build.ps1') -Configuration $Configuration
$projectRoot = Split-Path $PSScriptRoot -Parent
& (Join-Path $projectRoot "bin\$Configuration\ConfigTool.exe") self-test
if ($LASTEXITCODE -ne 0) { throw 'Fallaron las pruebas de protección.' }
