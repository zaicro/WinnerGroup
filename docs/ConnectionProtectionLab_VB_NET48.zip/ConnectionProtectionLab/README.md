# Laboratorio de protección de conexiones — VB.NET / .NET Framework 4.8

Proyecto para decidir cómo proteger la conexión de una aplicación WinForms distribuida copiando `bin`, con una posible migración a ClickOnce. Incluye código fuente, cuatro variantes, herramienta de preparación y pruebas ejecutables en Windows. No requiere NuGet, SQL Server ni una base de datos: usa una conexión ficticia y no intenta conectarse.

## 1. Empezar en cinco minutos

Requisitos: Windows, Visual Studio con la carga «Desarrollo de escritorio de .NET», herramientas de VB.NET y .NET Framework 4.8 Developer/Targeting Pack. El runtime 4.8 por sí solo no basta para compilar.

1. Abre `ConnectionProtectionLab.sln`.
2. Establece **Demo** como proyecto de inicio; compila Debug o Release.
3. Ejecuta `ConnectionProtectionDemo.exe` desde `bin\Debug` o `bin\Release`.
4. Selecciona **4. Archivo externo · DPAPI por usuario** y pulsa guardar; después leer.
5. Cierra y vuelve a abrir: la lectura debe seguir funcionando. La ventana no muestra la contraseña al leer ni abre conexiones.

La entrada de la ventana solo se usa en la opción 4. Las opciones 1–3 protegen la conexión `DemoDb` que ya está en el `.exe.config`. Para editarlas usa una copia de prueba sin cifrar, con el programa cerrado. No uses credenciales reales para este laboratorio.

También puedes compilar desde PowerShell, en la raíz de la solución:

```powershell
.\scripts\Build.ps1 -Configuration Release
.\scripts\Test.ps1 -Configuration Release
```

No necesitas cambiar globalmente la política de ejecución. Si Windows bloquea un archivo descargado, revisa sus propiedades/origen y aplica la política permitida por tu organización.

## 2. Comparación para tomar la decisión

| Opción implementada | Qué protege | ¿Mismo cifrado en varios equipos? | ¿Preparar cada destino? | Ventaja principal | Desventaja principal | ClickOnce |
|---|---|---|---|---|---|---|
| 1. Sección `.config`, DPAPI por equipo | `connectionStrings` completa | No de forma portable; se cifra en el destino | Sí: cifrar con permisos de escritura | Sin administrar una clave propia; lectura estándar | El ámbito equipo no distingue aplicaciones o usuarios; requiere ACL del archivo | No modificar el config desplegado; preferir variante externa |
| 2. Sección `.config`, DPAPI por usuario | `connectionStrings` completa | Vinculada al contexto del usuario; no asumir portabilidad | Sí: cifrar bajo la cuenta real | Mejor aislamiento entre cuentas del equipo | Si cifra otra cuenta, la app no podrá leer; escribe junto al exe | No modificar el config desplegado; preferir variante externa |
| 3. Sección `.config`, RSA | `connectionStrings` completa | Sí, con la misma clave privada provisionada | Sí: importar clave bajo cada cuenta que ejecutará la app | Permite entregar el config ya cifrado y leer con `ConfigurationManager` | Gestión y traslado de clave privada; compartirla amplía el impacto de una filtración | Viable si se cifra antes de generar/firmar manifiestos y la clave ya existe en destino |
| 4. Archivo externo, DPAPI CurrentUser | La cadena guardada en un archivo binario | No asumir portabilidad entre cuentas/equipos | Sí: configurar la conexión inicialmente | No modifica archivos publicados; no exige elevación en el uso normal | Usa una función propia de lectura y requiere configuración/recuperación por usuario | La opción más sencilla de este laboratorio para ClickOnce |

**Alcance de RSA en este ejemplo:** usa un contenedor **por usuario**, no por equipo, llamado `ConnectionProtectionLab.Rsa.v1`. Todas las herramientas y el proveedor están configurados igual. Importa la clave con la misma cuenta Windows que ejecuta la aplicación. Una consola elevada bajo OTRA cuenta no prepara el perfil del usuario final. Si se adapta a contenedor por equipo, hay que cambiar tanto el proveedor como la administración de claves y establecer permisos explícitos.

**DPAPI no reconoce “mi aplicación”.** `CurrentUser` protege respecto de otras identidades; otro proceso que se ejecute bajo el mismo usuario puede descifrar si tiene acceso al archivo. `LocalMachine` es aún más amplio: cualquier usuario del equipo con acceso al blob puede usar DPAPI para descifrarlo. No sustituyen los permisos NTFS ni protegen frente a un administrador que controla el equipo.

DPAPI CurrentUser normalmente depende del perfil/credenciales del usuario en ese equipo. Existen escenarios de perfiles itinerantes y recuperación de dominio: no interpretes esa vinculación como una garantía universal de que el blob jamás pueda descifrarse en otro equipo.

## 3. Qué hay en la solución

- `Core/ConfigurationProtection.vb`: protege/lee secciones con `System.Configuration`; impide cambiar accidentalmente de proveedor.
- `Core/ExternalSecret.vb`: `ProtectedData.Protect/Unprotect`, `CurrentUser`, escritura de bytes cifrados y reemplazo de archivo.
- `Core/RsaKeys.vb`: creación, exportación e importación de contenedor RSA de usuario.
- `Demo/`: WinForms construido por código; permite guardar/proteger y comprobar lectura sin revelar la contraseña.
- `Tool/`: consola para cifrar ANTES de distribuir y para preparar RSA; incluye `self-test`.
- `scripts/`: compilación y pruebas con MSBuild.

Los tres proyectos escriben su salida en `bin\<Configuration>`. En un despliegue real copia solo la aplicación, sus DLL y configuración; `ConfigTool.exe` es una herramienta de administración y laboratorio. No distribuyas claves exportadas, fuente con secretos ni PDB sin necesidad.

## 4. Probar DPAPI en el .exe.config

Trabaja en una copia independiente de `bin\Release`, fuera de `Program Files`, bajo tu perfil y con la app cerrada. Desde esa copia:

```powershell
# Cifrado por equipo:
.\ConfigTool.exe protect '.\ConnectionProtectionDemo.exe.config' machine
.\ConfigTool.exe read-check '.\ConnectionProtectionDemo.exe.config'
.\ConnectionProtectionDemo.exe
```

Para usuario, parte de OTRA copia sin cifrar:

```powershell
.\ConfigTool.exe protect '.\ConnectionProtectionDemo.exe.config' user
.\ConfigTool.exe read-check '.\ConnectionProtectionDemo.exe.config'
```

También se puede proteger desde la ventana para el despliegue por copia. No se cifra automáticamente al arrancar: evita contaminar sin darte cuenta el `bin` que luego repartirás. La ventana bloquea esa escritura si detecta ejecución mediante ClickOnce.

Al leer, .NET descifra en memoria automáticamente; el archivo sigue cifrado. No se llama a `UnprotectSection()` para conectarse.

Para volver a texto claro SOLO en laboratorio y con datos ficticios:

```powershell
.\ConfigTool.exe unprotect-lab '.\ConnectionProtectionDemo.exe.config' --write-plaintext
```

Esto permite probar otro proveedor. **Escribe la conexión en claro en disco**. No se ofrece en la ventana ni se ejecuta en el uso normal.

Si la carpeta no permite escritura, el cifrado del config fallará. No soluciones esto ejecutando toda la aplicación siempre como administrador: cifra durante una preparación controlada o usa el archivo externo.

## 5. RSA: config ya cifrado al entregar

### Equipo que prepara la versión

Con una copia sin cifrar y bajo la cuenta de preparación:

```powershell
.\ConfigTool.exe rsa-create
.\ConfigTool.exe protect '.\ConnectionProtectionDemo.exe.config' rsa
.\ConfigTool.exe read-check '.\ConnectionProtectionDemo.exe.config'

# Ejemplo: prepara previamente una carpeta privada de traslado fuera de bin.
# Sustituye esta ruta por una carpeta tuya con permisos restringidos.
.\ConfigTool.exe rsa-export-private 'C:\TrasladoPrivado\lab-private.xml' --allow-plaintext-private-key
```

Ejecuta `rsa-create` solo una vez para esa identidad. El programa rechaza reemplazar un contenedor existente. Una nueva compilación NO exige una nueva clave: vuelve a proteger el config generado con la clave existente. Conserva un respaldo seguro para poder preparar versiones futuras.

### Preparar versiones nuevas con un script

Una vez creado o importado el contenedor RSA en la cuenta de preparación, desde la raíz:

```powershell
.\scripts\Prepare-RsaPackage.ps1 -Configuration Release
```

Compila, copia solo los archivos de ejecución a una carpeta temporal, cifra la copia del config, comprueba que pueda leerse y genera `artifacts\RsaCopyPackage`. No modifica el config de `bin`, no exporta la clave y no sobrescribe un paquete existente. Si falla, elimina la carpeta temporal. Las credenciales reales nunca deben llegar a `bin` sin un proceso de preparación controlado.

Este script produce un paquete para **copia de carpeta**, no una publicación ClickOnce. La integración con el pipeline de ClickOnce se explica en la sección 7.

### Cada equipo/usuario de destino

1. Copia los binarios y el config ya cifrado.
2. Lleva temporalmente la clave por un canal controlado, fuera de la carpeta de la aplicación.
3. Ejecuta, con la cuenta que usará la app:

```powershell
.\ConfigTool.exe rsa-import-private 'C:\TrasladoPrivado\lab-private.xml'
.\ConfigTool.exe read-check '.\ConnectionProtectionDemo.exe.config'
.\ConnectionProtectionDemo.exe
```

4. Retira el archivo exportado del destino y de cualquier carpeta de distribución, sincronización o publicación. La eliminación normal no garantiza borrado forense; el traslado y respaldo deben protegerse desde el principio.

**El XML exportado contiene la clave PRIVADA SIN CIFRAR.** La opción explícita de consola recuerda ese riesgo, no lo mitiga. Este traslado manual es una demostración; para producción utiliza un mecanismo de aprovisionamiento administrado y almacenamiento seguro del respaldo. No adjuntes el XML a ClickOnce ni lo incrustes en una DLL.

El contenedor de Windows persiste después de cerrar el programa y no se guarda dentro de `bin`. Se crea exportable para demostrar migración entre equipos: esa comodidad tiene un coste de seguridad. La herramienta no elimina ni rota la clave de uso normal; una rotación necesita un plan que mantenga la lectura de configuraciones anteriores.

En el cliente la lectura permanece habitual:

```vbnet
Dim cadena As String =
    ConfigurationManager.ConnectionStrings("DemoDb").ConnectionString
```

## 6. Archivo externo: copia de bin y ClickOnce

La opción 4 guarda en:

```text
%LocalAppData%\ConnectionProtectionLab\connection.dpapi
```

Esa ruta es fija y no incluye versión ni ubicación del ejecutable. Dos versiones o canales del laboratorio bajo la misma cuenta comparten el archivo. En producción define empresa, producto y ambiente para no mezclar pruebas con producción.

```vbnet
' Configuración inicial: la entrada llega de una pantalla u otro canal autorizado.
ExternalSecret.Save(cadenaIntroducida, ExternalSecret.DefaultPath())

' Uso normal: centraliza esta llamada en tu fábrica de conexiones.
Dim cadena As String = ExternalSecret.Read(ExternalSecret.DefaultPath())
```

No se guarda la cadena en claro en un archivo temporal. El reemplazo usa `File.Replace` cuando ya existe el destino. Un error de escritura/cifrado se propaga; no hay una alternativa automática que deje el secreto en claro. El archivo hereda los permisos del directorio del perfil; las ACL siguen siendo parte de la protección.

Una actualización por copia o ClickOnce puede seguir leyendo el archivo porque está fuera de la carpeta de instalación. Esto NO es una migración automática de `user.config`: es almacenamiento propio. La aplicación debe gestionar cambios de formato, credenciales y recuperación. Una desinstalación puede dejar el archivo; define explícitamente la política de limpieza. Si se pierde el perfil o no se puede descifrar, habrá que volver a configurar.

## 7. ClickOnce: qué está resuelto y qué no

El ZIP contiene una solución WinForms normal; **no incluye una publicación ClickOnce, certificado de firma ni pipeline de publicación preconfigurado**. Puedes publicar Demo con el asistente de Visual Studio y seleccionar los archivos de ejecución necesarios.

- Opción 4: publica ejecutable y Core; configura el secreto en la primera ejecución. No publiques `connection.dpapi` ni claves privadas.
- RSA: integra el cifrado del config en la preparación de los archivos que realmente recoge la publicación, **antes de calcular hashes y generar/firmar manifiestos**. El cliente requiere la clave de usuario previamente provisionada.
- No supongas que cifrar manualmente un archivo de `bin` hará que «Publicar» use ese mismo archivo: el proceso puede regenerar el `.exe.config`. Hay que verificar el archivo final dentro de la publicación.
- No edites el config después de publicar ni reutilices un archivo DPAPI cifrado en la máquina de desarrollo como configuración general de todos los clientes.
- ClickOnce y la firma garantizan aspectos del despliegue; no convierten automáticamente las contraseñas del config en secretos.

El laboratorio no automatiza esa integración RSA/ClickOnce: permite comprobar cifrado, provisión y lectura antes de invertir en el pipeline.

## 8. ¿Se puede cifrar durante la compilación sin preparar los equipos?

Puedes automatizar el cifrado RSA con `ConfigTool protect ... rsa` tras generar el config. Pero alguien debe proporcionar la clave privada a cada identidad cliente. DPAPI evita administrar una clave propia, a cambio de proteger en el contexto de destino.

| Alternativa adicional (no implementada) | Beneficio | Coste / límite |
|---|---|---|
| AES con clave incrustada en EXE/DLL | Paquete autónomo; oculta lectura casual | Quien obtiene el paquete tiene datos y mecanismo para recuperar la clave; no ofrece la separación de claves de este laboratorio |
| Proveedor propio `ProtectedConfigurationProvider` | Puede mantener lectura transparente de configuración | Hay que implementar y mantener criptografía, autenticidad y distribución de claves; no elimina el problema de aprovisionamiento |
| Autenticación Windows para SQL Server | No distribuyes contraseña SQL | Requiere identidades, permisos y conectividad adecuados; el usuario autorizado puede acceder con otra herramienta |
| API intermedia con autenticación/autorización por usuario | La contraseña de la BD queda en el servidor; permite controlar operaciones | Requiere backend, disponibilidad, identidad y operación; es un cambio de arquitectura |

No se incluye un ejemplo de AES con clave fija para no presentarlo como equivalente a una clave administrada por Windows. No hay un ajuste de Release, obfuscación o ClickOnce que garantice esconder una contraseña compartida frente a quien controla el cliente.

## 9. Límites que afectan a la decisión

- Se protege el secreto **en disco**; para conectarse existirá como texto en la memoria del proceso. Los `String` de .NET no pueden borrarse de forma fiable; limpiar un array de bytes no elimina todas las copias.
- Evita registrar cadenas, excepciones con XML, contraseñas o parámetros de línea de comandos que contengan secretos. Los comandos del ejemplo no reciben contraseñas.
- Si todas las instalaciones usan un mismo usuario SQL, extraer esa contraseña en un cliente afecta a todos. Aplica mínimos privilegios y diseña revocación/rotación.
- El cifrado del config no cifra la BD ni el tráfico de red. TLS y permisos de base de datos son decisiones independientes.
- No reemplaces el config protegido del destino por uno sin cifrar durante una actualización por copia. Si el config cambió, planifica una preparación/migración explícita.
- La carpeta de compilación contiene la conexión ficticia en claro por diseño. En producción evita almacenar secretos reales en `App.config`, Git, logs o artefactos intermedios accesibles; usa un canal de preparación controlado.
- Usa Release para distribuir. Release no es una medida de protección de credenciales.

## 10. Pruebas y estado de validación

Esta entrega se generó en Linux sin Visual Studio/MSBuild ni runtime .NET Framework 4.8. Se revisaron estáticamente XML de proyectos/configuración, referencias, estructura y empaquetado. **No se compiló ni se ejecutó la interfaz, DPAPI, RSA o ClickOnce en este entorno.** No se incluyen binarios supuestamente validados.

Ejecuta `scripts\Test.ps1` en Windows. `ConfigTool self-test` utiliza archivos temporales y un contenedor RSA de prueba con nombre aleatorio; los elimina al terminar. No utiliza ni reemplaza el contenedor normal del laboratorio.

Comprueba: round-trip y ausencia del secreto en el texto del archivo en tres proveedores, protección repetida con el mismo proveedor, rechazo de cambio accidental, reversión explícita de laboratorio, guardado/lectura/reemplazo externo y rechazo de un archivo DPAPI inválido. Sale con código distinto de cero ante un fallo. Estas pruebas locales no prueban provisión entre máquinas.

Pruebas manuales decisivas:

| Prueba | Resultado esperado |
|---|---|
| Cerrar/reabrir app con cada modo | Sigue leyendo la misma conexión |
| Copiar config DPAPI por equipo a otro equipo sin prepararlo | No debe asumirse que se pueda descifrar; en equipos independientes fallará |
| Leer config DPAPI CurrentUser con otra cuenta local independiente | Falla el descifrado |
| Copiar config RSA a otro equipo antes de importar | Falla la lectura |
| Importar la misma clave RSA bajo la cuenta correcta y volver a leer | Funciona |
| Leer archivo externo con otra cuenta independiente | Falla el descifrado |
| Actualizar app conservando la ruta externa bajo la misma identidad | Sigue leyendo el archivo externo |
| Publicar ClickOnce con RSA y revisar artefacto final | El config publicado contiene `EncryptedData`, no la contraseña |

Errores típicos: permisos de escritura, perfil equivocado, clave RSA diferente o ausente, proveedor no declarado, config protegido en otra máquina, configuración regenerada por compilación/publicación. La ventana oculta mensajes detallados de excepciones para evitar revelar secretos. Con datos ficticios puedes depurar con Visual Studio y comprobar la causa.

## 11. Recomendación para tu escenario

1. **Primero prueba la opción 4** si aceptas configurar la conexión una vez por usuario. Es la menos acoplada al mecanismo de distribución y permite pasar de copia de `bin` a ClickOnce.
2. **Prueba RSA** si necesitas que la versión salga ya cifrada y puedes gestionar la clave de cada destino. No incrustes ni distribuyas la clave privada junto con la aplicación.
3. **DPAPI por equipo en el config** es una alternativa simple para el despliegue actual por copia si cifras en destino y controlas permisos; no es la más cómoda para una futura publicación ClickOnce.
4. Si el objetivo es impedir que un usuario del cliente obtenga una contraseña de una base central, evalúa autenticación Windows o API antes de invertir en cifrado local.

El siguiente paso más útil es ejecutar las pruebas locales y la prueba RSA en dos equipos con datos ficticios. Decide por el coste de configuración, actualizaciones y rotación, no solo por si el archivo queda ilegible.

## 12. Referencias oficiales

- [ADO.NET: conexiones, configuración y protección de secciones para aplicaciones Windows](https://learn.microsoft.com/en-us/dotnet/framework/data/adonet/connection-strings-and-configuration-files).
- [Artículo VB que motivó el ejemplo](https://learn.microsoft.com/es-es/aspnet/web-forms/overview/data-access/advanced-data-access-scenarios/protecting-connection-strings-and-other-configuration-information-vb).
- [RsaProtectedConfigurationProvider y métodos de administración](https://learn.microsoft.com/en-us/dotnet/api/system.configuration.rsaprotectedconfigurationprovider?view=netframework-4.8.1).
- [Importación y exportación de contenedores RSA](https://learn.microsoft.com/en-us/previous-versions/aspnet/yxw286t2(v=vs.100)). Los comandos web del artículo se sustituyen aquí por la consola VB; no se requiere IIS.
- [ProtectedData: DPAPI](https://learn.microsoft.com/en-us/dotnet/api/system.security.cryptography.protecteddata?view=netframework-4.8.1).
- [Ámbitos de protección de datos](https://learn.microsoft.com/en-us/dotnet/api/system.security.cryptography.dataprotectionscope?view=netframework-4.8.1).
- [ClickOnce y configuración](https://learn.microsoft.com/en-us/visualstudio/deployment/clickonce-and-application-settings?view=visualstudio).
- [Protección de información de conexión](https://learn.microsoft.com/en-us/dotnet/framework/data/adonet/protecting-connection-information).
