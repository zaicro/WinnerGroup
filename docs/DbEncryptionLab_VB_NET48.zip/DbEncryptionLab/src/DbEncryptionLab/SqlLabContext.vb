Imports System.Data.Common
Imports System.Data.Entity
Imports System.Data.Entity.SqlServer
Imports System.Data.SqlClient

Public Class SqlLabConfiguration
    Inherits DbConfiguration

    Public Sub New()
        SetProviderFactory("System.Data.SqlClient", SqlClientFactory.Instance)
        SetProviderServices("System.Data.SqlClient", SqlProviderServices.Instance)
    End Sub
End Class

Public Class DatoPrueba
    Public Property Id As Integer
    Public Property Mensaje As String
End Class

<DbConfigurationType(GetType(SqlLabConfiguration))>
Public Class SqlLabContext
    Inherits DbContext

    Public Sub New(connectionString As String)
        MyBase.New(New SqlConnection(connectionString), True)
        Configuration.LazyLoadingEnabled = False
        Configuration.ProxyCreationEnabled = False
    End Sub

    Public Property Datos As DbSet(Of DatoPrueba)

    Protected Overrides Sub OnModelCreating(modelBuilder As DbModelBuilder)
        Dim entity = modelBuilder.Entity(Of DatoPrueba)()
        entity.ToTable("DatoPrueba", "dbo")
        entity.HasKey(Function(x) x.Id)
        entity.Property(Function(x) x.Mensaje).IsRequired().HasMaxLength(200)
        MyBase.OnModelCreating(modelBuilder)
    End Sub
End Class
