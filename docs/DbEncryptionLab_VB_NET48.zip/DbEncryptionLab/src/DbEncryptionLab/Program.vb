Imports System.Configuration
Imports System.Data.Entity
Imports System.Data.SqlClient
Imports System.Linq
Imports System.Text
Imports Npgsql

Module Program
    Private Const SampleMessage As String = "DATO-LAB-7319: prueba de cifrado transparente"
    Private PgConnection As String

    Sub Main(args As String())
        Console.OutputEncoding = Encoding.UTF8
        Database.SetInitializer(Of SqlLabContext)(Nothing)
        Console.WriteLine("Laboratorio VB.NET / .NET Framework 4.8. Solo bases de prueba.")
        Console.WriteLine("No se borran bases. El cifrado se habilita con los scripts del README.")
        Do
            Console.WriteLine()
            Console.WriteLine("1. SQL Server: crear base/tabla con EF6 e insertar un dato")
            Console.WriteLine("2. SQL Server: consultar con ADO.NET (sin crear nada)")
            Console.WriteLine("3. SQL Server: consultar estado TDE")
            Console.WriteLine("4. PostgreSQL: crear base/tabla tde_heap e insertar un dato")
            Console.WriteLine("5. PostgreSQL: consultar con Npgsql (sin crear nada)")
            Console.WriteLine("6. PostgreSQL: consultar estado pg_tde/WAL")
            Console.WriteLine("0. Salir")
            Console.Write("Opción: ")
            Dim choice = Console.ReadLine()
            If choice Is Nothing OrElse choice = "0" Then Exit Do
            Try
                Select Case choice
                    Case "1" : CreateSql()
                    Case "2" : QuerySql()
                    Case "3" : StatusSql()
                    Case "4" : CreatePg()
                    Case "5" : QueryPg()
                    Case "6" : StatusPg()
                    Case Else : Console.WriteLine("Opción no válida.")
                End Select
            Catch ex As Exception
                Console.ForegroundColor = ConsoleColor.Red
                Console.WriteLine("Operación fallida. No se continuará con esta operación.")
                Console.WriteLine(ex.GetBaseException().Message)
                Console.ResetColor()
                Console.WriteLine("Revisa el apartado de errores del README. No se imprime la conexión.")
            End Try
        Loop
    End Sub

    Private Function SqlConnectionString() As String
        Dim value = Environment.GetEnvironmentVariable("LAB_SQL_CONNECTION")
        If String.IsNullOrWhiteSpace(value) Then value = ConfigurationManager.ConnectionStrings("SqlLab").ConnectionString
        Dim b As New SqlConnectionStringBuilder(value)
        If Not String.Equals(b.InitialCatalog, "DemoCifradoSql", StringComparison.OrdinalIgnoreCase) Then
            Throw New InvalidOperationException("La base SQL del laboratorio debe llamarse DemoCifradoSql.")
        End If
        Return b.ConnectionString
    End Function

    Private Function PgConnectionString() As String
        If PgConnection IsNot Nothing Then Return PgConnection
        Dim value = Environment.GetEnvironmentVariable("LAB_PG_CONNECTION")
        If String.IsNullOrWhiteSpace(value) Then value = ConfigurationManager.ConnectionStrings("PgLab").ConnectionString
        Dim b As New NpgsqlConnectionStringBuilder(value)
        If b.Database <> "demo_cifrado_pg" Then Throw New InvalidOperationException("La base PG debe llamarse demo_cifrado_pg.")
        If b.Password = "CAMBIAR_EN_CONSOLA" OrElse String.IsNullOrEmpty(b.Password) Then
            Console.Write("Contraseña del usuario PostgreSQL (no se muestra): ")
            b.Password = ReadPassword()
        End If
        PgConnection = b.ConnectionString
        Return PgConnection
    End Function

    Private Function ReadPassword() As String
        Dim result As New StringBuilder()
        Do
            Dim key = Console.ReadKey(True)
            If key.Key = ConsoleKey.Enter Then Exit Do
            If key.Key = ConsoleKey.Backspace Then
                If result.Length > 0 Then result.Length -= 1
            ElseIf Not Char.IsControl(key.KeyChar) Then
                result.Append(key.KeyChar)
            End If
        Loop
        Console.WriteLine()
        Return result.ToString()
    End Function

    Private Sub CreateSql()
        Using db As New SqlLabContext(SqlConnectionString())
            If Not db.Database.Exists() Then
                db.Database.Create()
                Console.WriteLine("Base y tabla creadas por EF6.")
            End If
            ' No se usa DropCreateDatabase ni se reemplaza un esquema existente.
            If Not db.Datos.Any() Then
                db.Datos.Add(New DatoPrueba With {.Mensaje = SampleMessage})
                db.SaveChanges()
            End If
            Console.WriteLine("Dato disponible. Ejecuta opción 2 y después el script TDE.")
        End Using
    End Sub

    Private Sub QuerySql()
        Using cn As New SqlConnection(SqlConnectionString())
            cn.Open()
            Using cmd As New SqlCommand("SELECT Id, Mensaje FROM dbo.DatoPrueba ORDER BY Id", cn)
                Using reader = cmd.ExecuteReader()
                    While reader.Read()
                        Console.WriteLine("{0}: {1}", reader.GetInt32(0), reader.GetString(1))
                    End While
                End Using
            End Using
        End Using
    End Sub

    Private Sub StatusSql()
        Using cn As New SqlConnection(SqlConnectionString())
            cn.Open()
            Using cmd As New SqlCommand("SELECT encryption_state, percent_complete FROM sys.dm_database_encryption_keys WHERE database_id=DB_ID()", cn)
                Using reader = cmd.ExecuteReader()
                    If reader.Read() Then
                        Console.WriteLine("encryption_state={0}; percent_complete={1}", reader(0), reader(1))
                        Console.WriteLine("El estado esperado al terminar es 3 (cifrada).")
                    Else
                        Console.WriteLine("No existe DEK visible: no se demuestra cifrado. Ejecuta con usuario de laboratorio autorizado.")
                    End If
                End Using
            End Using
        End Using
    End Sub

    Private Sub CreatePg()
        Dim target = PgConnectionString()
        Dim admin As New NpgsqlConnectionStringBuilder(target) With {.Database = "postgres"}
        Using cn As New NpgsqlConnection(admin.ConnectionString)
            cn.Open()
            Using check As New NpgsqlCommand("SELECT 1 FROM pg_database WHERE datname=@name", cn)
                check.Parameters.AddWithValue("name", "demo_cifrado_pg")
                If check.ExecuteScalar() Is Nothing Then
                    Using create As New NpgsqlCommand("CREATE DATABASE demo_cifrado_pg", cn)
                        create.ExecuteNonQuery()
                    End Using
                    Console.WriteLine("Base PostgreSQL creada.")
                End If
            End Using
        End Using
        Using cn As New NpgsqlConnection(target)
            cn.Open()
            Using cmd As New NpgsqlCommand("SHOW pg_tde.wal_encrypt", cn)
                If Convert.ToString(cmd.ExecuteScalar()) <> "on" Then
                    Throw New InvalidOperationException("Primero habilita WAL con postgres/Setup-PgTde.ps1. No se insertarán datos.")
                End If
            End Using
            Using tx = cn.BeginTransaction()
                Using cmd As New NpgsqlCommand("CREATE EXTENSION IF NOT EXISTS pg_tde; CREATE TABLE IF NOT EXISTS public.dato_prueba (id integer PRIMARY KEY, mensaje varchar(200) NOT NULL) USING tde_heap;", cn, tx)
                    cmd.ExecuteNonQuery()
                End Using
                Using cmd As New NpgsqlCommand("SELECT pg_tde_is_encrypted('public.dato_prueba')", cn, tx)
                    If Not Convert.ToBoolean(cmd.ExecuteScalar()) Then Throw New InvalidOperationException("La tabla existente no está cifrada. No se insertarán datos.")
                End Using
                Using cmd As New NpgsqlCommand("INSERT INTO public.dato_prueba(id,mensaje) VALUES (1,@message) ON CONFLICT (id) DO NOTHING", cn, tx)
                    cmd.Parameters.AddWithValue("message", SampleMessage)
                    cmd.ExecuteNonQuery()
                End Using
                tx.Commit()
            End Using
        End Using
        Console.WriteLine("Tabla tde_heap y dato disponibles. Consulta con opción 5.")
    End Sub

    Private Sub QueryPg()
        Using cn As New NpgsqlConnection(PgConnectionString())
            cn.Open()
            Using cmd As New NpgsqlCommand("SELECT id,mensaje FROM public.dato_prueba ORDER BY id", cn)
                Using reader = cmd.ExecuteReader()
                    While reader.Read()
                        Console.WriteLine("{0}: {1}", reader.GetInt32(0), reader.GetString(1))
                    End While
                End Using
            End Using
        End Using
    End Sub

    Private Sub StatusPg()
        Using cn As New NpgsqlConnection(PgConnectionString())
            cn.Open()
            Using cmd As New NpgsqlCommand("SELECT extversion FROM pg_extension WHERE extname='pg_tde'", cn)
                Console.WriteLine("pg_tde: {0}", cmd.ExecuteScalar())
            End Using
            Using cmd As New NpgsqlCommand("SHOW pg_tde.wal_encrypt", cn)
                Console.WriteLine("WAL cifrado: {0}", cmd.ExecuteScalar())
            End Using
            Using cmd As New NpgsqlCommand("SELECT pg_tde_is_encrypted('public.dato_prueba')", cn)
                Console.WriteLine("Tabla cifrada: {0}", cmd.ExecuteScalar())
            End Using
        End Using
    End Sub
End Module
