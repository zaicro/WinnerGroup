-- SOLO .\LABSQLCOPY. Ruta alternativa a 04-Restore-Copy.sql.
-- Archivos copiados con la base origen OFFLINE y sin modificar los originales.
USE master;
GO
IF DB_ID(N'DemoCifradoSqlCopia') IS NOT NULL
    THROW 51000, 'La base copia ya existe. Usa un laboratorio limpio.', 1;
CREATE DATABASE DemoCifradoSqlCopia ON
(FILENAME=N'C:\DbEncryptionLab\SqlCopyData\DemoCifradoSqlCopia.mdf'),
(FILENAME=N'C:\DbEncryptionLab\SqlCopyData\DemoCifradoSqlCopia_log.ldf')
FOR ATTACH;
GO
SELECT Id, Mensaje FROM DemoCifradoSqlCopia.dbo.DatoPrueba;
