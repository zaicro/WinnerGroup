-- SSMS: ejecutar en .\LABSQL como administrador del laboratorio.
-- Antes: opción 1 de la consola. Crear carpeta y dar permisos al servicio SQL.
-- CAMBIAR las dos contraseñas. No son credenciales de conexión de la aplicación.
USE master;
GO
SET NOCOUNT ON;
DECLARE @MasterPassword nvarchar(128) = N'CAMBIAR_MASTER_PASSWORD';
DECLARE @ExportPassword nvarchar(128) = N'CAMBIAR_EXPORT_PASSWORD';
IF @MasterPassword LIKE N'CAMBIAR%' OR @ExportPassword LIKE N'CAMBIAR%'
    THROW 51000, 'Edita las contraseñas del script antes de ejecutarlo.', 1;
IF DB_ID(N'DemoCifradoSql') IS NULL
    THROW 51000, 'Primero crea DemoCifradoSql con la consola.', 1;
IF CONVERT(nvarchar(128), SERVERPROPERTY('Edition')) LIKE N'%Express%'
    THROW 51000, 'TDE no está disponible en Express/LocalDB.', 1;
IF NOT EXISTS (SELECT 1 FROM sys.symmetric_keys WHERE name=N'##MS_DatabaseMasterKey##')
    EXEC(N'CREATE MASTER KEY ENCRYPTION BY PASSWORD = ' + QUOTENAME(@MasterPassword, ''''));
IF NOT EXISTS (SELECT 1 FROM sys.certificates WHERE name=N'LabTdeCertificate')
    EXEC(N'CREATE CERTIFICATE LabTdeCertificate WITH SUBJECT = ''TDE laboratorio''');
-- Estas rutas son del servidor SQL, no del PC que ejecuta SSMS.
-- Los archivos de salida no deben existir. Al repetir usa nombres nuevos.
EXEC(N'BACKUP CERTIFICATE LabTdeCertificate
 TO FILE = ''C:\DbEncryptionLab\SqlKeys\LabTdeCertificate.cer''
 WITH PRIVATE KEY (FILE = ''C:\DbEncryptionLab\SqlKeys\LabTdeCertificate.pvk'',
 ENCRYPTION BY PASSWORD = ' + QUOTENAME(@ExportPassword, '''') + N')');
GO
USE DemoCifradoSql;
GO
IF NOT EXISTS (SELECT 1 FROM sys.dm_database_encryption_keys WHERE database_id=DB_ID())
    CREATE DATABASE ENCRYPTION KEY WITH ALGORITHM = AES_256
    ENCRYPTION BY SERVER CERTIFICATE LabTdeCertificate;
ALTER DATABASE DemoCifradoSql SET ENCRYPTION ON;
GO
-- Esperar a encryption_state=3 antes de copiar archivos o hacer la prueba.
SELECT DB_NAME(database_id) AS DatabaseName, encryption_state, percent_complete
FROM sys.dm_database_encryption_keys WHERE database_id=DB_ID();
