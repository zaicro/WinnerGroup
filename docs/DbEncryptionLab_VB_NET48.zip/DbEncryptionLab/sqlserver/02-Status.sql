SELECT @@SERVERNAME AS InstanceName,
       SERVERPROPERTY('ProductVersion') AS ProductVersion,
       SERVERPROPERTY('Edition') AS Edition;
SELECT DB_NAME(database_id) AS DatabaseName, encryption_state, percent_complete
FROM sys.dm_database_encryption_keys WHERE database_id=DB_ID(N'DemoCifradoSql');
SELECT name, physical_name FROM sys.master_files WHERE database_id=DB_ID(N'DemoCifradoSql');
SELECT Id, Mensaje FROM DemoCifradoSql.dbo.DatoPrueba;
