-- SOLO .\LABSQLCOPY. Ejecutar DESPUÉS de demostrar el fallo sin certificado.
USE master;
GO
DECLARE @MasterPassword nvarchar(128)=N'CAMBIAR_DESTINATION_MASTER_PASSWORD';
DECLARE @ExportPassword nvarchar(128)=N'CAMBIAR_EXPORT_PASSWORD';
IF @MasterPassword LIKE N'CAMBIAR%' OR @ExportPassword LIKE N'CAMBIAR%'
    THROW 51000, 'Edita contraseñas. Export debe coincidir con 01-Enable-Tde.sql.', 1;
IF EXISTS(SELECT 1 FROM sys.certificates WHERE name=N'LabTdeCertificate')
    THROW 51000, 'El certificado ya está instalado: no sirve como prueba negativa limpia.', 1;
IF NOT EXISTS(SELECT 1 FROM sys.symmetric_keys WHERE name=N'##MS_DatabaseMasterKey##')
    EXEC(N'CREATE MASTER KEY ENCRYPTION BY PASSWORD='+QUOTENAME(@MasterPassword, ''''));
EXEC(N'CREATE CERTIFICATE LabTdeCertificate
 FROM FILE=''C:\DbEncryptionLab\SqlKeys\LabTdeCertificate.cer''
 WITH PRIVATE KEY (FILE=''C:\DbEncryptionLab\SqlKeys\LabTdeCertificate.pvk'',
 DECRYPTION BY PASSWORD='+QUOTENAME(@ExportPassword, '''')+N')');
