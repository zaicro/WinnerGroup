-- SOLO .\LABSQLCOPY. Primero sin certificado (debe fallar), después con él.
-- No ejecutar contra la instancia original. No usa WITH REPLACE.
USE master;
GO
IF DB_ID(N'DemoCifradoSqlCopia') IS NOT NULL
    THROW 51000, 'La base copia ya existe. Usa un laboratorio limpio.', 1;
-- Después de importar el certificado ejecuta FILELISTONLY y ajusta nombres lógicos.
-- RESTORE FILELISTONLY FROM DISK=N'C:\DbEncryptionLab\SqlBackups\DemoCifradoSql-Tde.bak';
RESTORE DATABASE DemoCifradoSqlCopia
FROM DISK=N'C:\DbEncryptionLab\SqlBackups\DemoCifradoSql-Tde.bak'
WITH FILE=1,
MOVE N'DemoCifradoSql' TO N'C:\DbEncryptionLab\SqlCopyData\DemoCifradoSqlCopia.mdf',
MOVE N'DemoCifradoSql_log' TO N'C:\DbEncryptionLab\SqlCopyData\DemoCifradoSqlCopia_log.ldf',
CHECKSUM;
GO
SELECT Id, Mensaje FROM DemoCifradoSqlCopia.dbo.DatoPrueba;
