-- .\LABSQL. La carpeta debe existir y ser escribible por el servicio SQL.
USE master;
GO
IF NOT EXISTS (SELECT 1 FROM sys.dm_database_encryption_keys
               WHERE database_id=DB_ID(N'DemoCifradoSql') AND encryption_state=3)
    THROW 51000, 'La base todavía no está completamente cifrada.', 1;
BACKUP DATABASE DemoCifradoSql
TO DISK=N'C:\DbEncryptionLab\SqlBackups\DemoCifradoSql-Tde.bak'
WITH COPY_ONLY, CHECKSUM;
-- Usa un archivo nuevo si repites: sin INIT se agregan juegos al mismo archivo.
