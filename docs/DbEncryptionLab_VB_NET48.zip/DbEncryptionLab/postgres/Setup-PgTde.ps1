﻿[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
function Invoke-Docker {
    & docker @args
    if ($LASTEXITCODE -ne 0) { throw "Docker falló: $($args -join ' ')" }
}
$container = 'db-encryption-lab-pg'
Invoke-Docker exec --user 0 $container bash -c 'mkdir -p /keys; chown postgres:postgres /keys; chmod 700 /keys'
& docker exec --user postgres $container test -f /keys/lab-global.per
if ($LASTEXITCODE -eq 0) {
    throw 'La clave ya existe. No se reemplaza. Verifica SHOW pg_tde.wal_encrypt; o sigue recuperación en README.'
}
Invoke-Docker cp (Join-Path $PSScriptRoot '00-Global-Key.sql') "${container}:/tmp/00-Global-Key.sql"
Invoke-Docker exec --user postgres $container psql -X -v ON_ERROR_STOP=1 -U postgres -d postgres -f /tmp/00-Global-Key.sql
Invoke-Docker restart $container
$ready = $false
for ($i=0; $i -lt 30; $i++) {
    & docker exec --user postgres $container pg_isready -U postgres -d postgres 2>$null | Out-Null
    if ($LASTEXITCODE -eq 0) { $ready=$true; break }
    Start-Sleep -Seconds 1
}
if (-not $ready) { throw 'PostgreSQL no arrancó. Revisa docker logs db-encryption-lab-pg.' }
Invoke-Docker exec --user postgres $container psql -X -v ON_ERROR_STOP=1 -U postgres -d postgres -c 'SHOW pg_tde.wal_encrypt;'
Write-Host 'Debe indicar on. Ahora ejecuta la opción 4 de la consola VB.'
