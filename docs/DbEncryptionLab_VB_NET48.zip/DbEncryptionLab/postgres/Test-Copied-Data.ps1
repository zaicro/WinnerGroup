﻿[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$image = 'percona/percona-distribution-postgresql:17.11'
$source = 'db-encryption-lab-pg'
$withKeys = 'db-encryption-lab-copy-with-keys'
$withoutKeys = 'db-encryption-lab-copy-no-keys'
$copyData1 = 'db-encryption-lab-copy-data-with-keys'
$copyData2 = 'db-encryption-lab-copy-data-no-keys'
$copyKeys = 'db-encryption-lab-copy-keys'
$emptyKeys = 'db-encryption-lab-empty-keys'
function Invoke-Docker {
    & docker @args
    if ($LASTEXITCODE -ne 0) { throw "Docker falló: $($args -join ' ')" }
}
function Invoke-CapturedDocker {
    $previousPreference = $ErrorActionPreference
    try {
        # PowerShell 5.1 puede convertir stderr nativo en ErrorRecord.
        $ErrorActionPreference = 'Continue'
        $output = & docker @args 2>&1
        $code = $LASTEXITCODE
        return @{ Output=($output | Out-String); ExitCode=$code }
    } finally {
        $ErrorActionPreference = $previousPreference
    }
}
function Wait-Pg {
    param([string]$Container, [int]$Attempts=30)
    for ($i=0; $i -lt $Attempts; $i++) {
        & docker exec --user postgres $Container pg_isready -U postgres -d demo_cifrado_pg 2>$null | Out-Null
        if ($LASTEXITCODE -eq 0) { return $true }
        $state = & docker inspect --format '{{.State.Running}}' $Container
        if ($state -ne 'true') { return $false }
        Start-Sleep -Seconds 1
    }
    return $false
}
# Evitar reutilizar una copia anterior, con datos o claves diferentes.
foreach ($name in @($withKeys,$withoutKeys)) {
    & docker container inspect $name 2>$null | Out-Null
    if ($LASTEXITCODE -eq 0) { throw "Ya existe $name. Revisa y elimina solo las copias según README." }
}
foreach ($name in @($copyData1,$copyData2,$copyKeys,$emptyKeys)) {
    & docker volume inspect $name 2>$null | Out-Null
    if ($LASTEXITCODE -eq 0) { throw "Ya existe $name. No se sobrescribirá." }
}
# Control previo: base correcta, mensaje correcto y tabla cifrada.
$preflight = Invoke-CapturedDocker exec --user postgres $source psql -X -A -t -v ON_ERROR_STOP=1 -U postgres -d demo_cifrado_pg -c "SELECT count(*) FROM public.dato_prueba WHERE id=1 AND mensaje='DATO-LAB-7319: prueba de cifrado transparente' AND pg_tde_is_encrypted('public.dato_prueba') AND current_setting('pg_tde.wal_encrypt')='on';"
if ($preflight.ExitCode -ne 0 -or $preflight.Output.Trim() -ne '1') {
    throw "Precondición fallida: falta el dato esperado, tabla cifrada o WAL. $($preflight.Output)"
}
$state = & docker inspect --format '{{.State.Running}}' $source
if ($state -ne 'true') { throw 'La instancia original debe estar ejecutándose.' }
try {
    Invoke-Docker stop $source
    foreach ($targetVolume in @($copyData1,$copyData2)) {
        Invoke-Docker volume create $targetVolume
        Invoke-Docker run --rm --user 0 --entrypoint /bin/bash -v db-encryption-lab-pgdata:/source:ro -v "${targetVolume}:/target" $image -c 'cp -a /source/. /target/'
    }
    Invoke-Docker volume create $copyKeys
    Invoke-Docker run --rm --user 0 --entrypoint /bin/bash -v db-encryption-lab-pgkeys:/source:ro -v "${copyKeys}:/target" $image -c 'cp -a /source/. /target/'
    Invoke-Docker volume create $emptyKeys
} finally {
    Invoke-Docker start $source
}
# Control positivo con los mismos binarios y una copia de la clave correcta.
Invoke-Docker run -d --name $withKeys --env PGDATA=/data/db/pgdata -v "${copyData1}:/data/db" -v "${copyKeys}:/keys" $image -c shared_preload_libraries=pg_tde
if (-not (Wait-Pg $withKeys)) {
    & docker logs $withKeys
    throw 'Control positivo falló: no se puede atribuir el fallo negativo al cifrado.'
}
Invoke-Docker exec --user postgres $withKeys psql -X -v ON_ERROR_STOP=1 -U postgres -d demo_cifrado_pg -c 'SELECT id,mensaje FROM public.dato_prueba;'
Invoke-Docker stop $withKeys
# Copia idéntica de datos, con directorio de claves vacío. Sin puertos publicados.
Invoke-Docker run -d --name $withoutKeys --env PGDATA=/data/db/pgdata -v "${copyData2}:/data/db" -v "${emptyKeys}:/keys" $image -c shared_preload_libraries=pg_tde
$ready = Wait-Pg $withoutKeys 15
$failedQuery = $false
$evidence = ''
if ($ready) {
    $queryResult = Invoke-CapturedDocker exec --user postgres $withoutKeys psql -X -v ON_ERROR_STOP=1 -U postgres -d demo_cifrado_pg -c 'SELECT id,mensaje FROM public.dato_prueba;'
    $failedQuery = ($queryResult.ExitCode -ne 0)
    $evidence = $queryResult.Output
    Write-Host $evidence
    if (-not $failedQuery) { throw 'FALLO DE LA PRUEBA: la copia sin claves permite leer el dato.' }
}
$logResult = Invoke-CapturedDocker logs $withoutKeys
$evidence += $logResult.Output
Write-Host $logResult.Output
& docker stop $withoutKeys 2>$null | Out-Null
if ((-not $ready -or $failedQuery) -and $evidence -match '(?i)keyring|principal key|key provider|lab-global\.per|encryption key') {
    Write-Host 'Resultado esperado: control con clave legible; copia sin clave falla y muestra evidencia relacionada con claves.'
} else {
    throw 'Resultado inconcluso: revisa los logs. Un fallo genérico de arranque/conexión no demuestra cifrado.'
}
Write-Host 'La instancia original fue reiniciada. Las copias quedan detenidas para inspección.'
