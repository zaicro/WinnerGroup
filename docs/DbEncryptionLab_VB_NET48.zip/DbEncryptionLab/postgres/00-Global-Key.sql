-- Primera ejecución, en postgres. Clave fuera de PGDATA, en volumen independiente.
CREATE EXTENSION IF NOT EXISTS pg_tde;
SELECT extversion FROM pg_extension WHERE extname='pg_tde';
SELECT pg_tde_add_global_key_provider_file('lab-global', '/keys/lab-global.per');
SELECT pg_tde_create_key_using_global_key_provider('lab-principal', 'lab-global');
SELECT pg_tde_set_default_key_using_global_key_provider('lab-principal', 'lab-global');
ALTER SYSTEM SET pg_tde.wal_encrypt = on;
-- Reiniciar antes de crear e insertar los datos de prueba.
