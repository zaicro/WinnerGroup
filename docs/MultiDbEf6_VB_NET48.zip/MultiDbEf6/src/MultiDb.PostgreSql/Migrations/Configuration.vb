﻿Imports System.Data.Entity.Infrastructure
Imports System.Data.Entity.Migrations
Imports System.Data.Entity.Migrations.Design

Namespace MultiDb.PostgreSql.Migrations
    Public Class Configuration
        Inherits DbMigrationsConfiguration(Of LabDbContext)

        Public Sub New()
            AutomaticMigrationsEnabled = False
            AutomaticMigrationDataLossAllowed = False
            ContextKey = "MultiDb.PostgreSql.LabDbContext"
            MigrationsNamespace = "MultiDb.PostgreSql.Migrations"
            MigrationsDirectory = "Migrations"
            MigrationsAssembly = GetType(Configuration).Assembly
            TargetDatabase = New DbConnectionInfo("LabDb")
            CodeGenerator = New VisualBasicMigrationCodeGenerator()
            SetSqlGenerator("Npgsql", New Npgsql.NpgsqlMigrationSqlGenerator())
        End Sub
    End Class
End Namespace
