﻿Namespace MultiDb.Oracle
    Friend Module Program
        Public Function Main(args As String()) As Integer
            Return MultiDb.Tools.MigrationConsole.Run(Of LabDbContext)(args, New Migrations.Configuration(), Function() New LabDbContext())
        End Function
    End Module
End Namespace
