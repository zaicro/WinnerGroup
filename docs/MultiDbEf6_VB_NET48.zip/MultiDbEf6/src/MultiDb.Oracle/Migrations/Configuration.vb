﻿Imports System.Data.Entity.Infrastructure
Imports System.Data.Entity.Migrations
Imports System.Data.Entity.Migrations.Design

Namespace MultiDb.Oracle.Migrations
    Public Class Configuration
        Inherits DbMigrationsConfiguration(Of LabDbContext)

        Public Sub New()
            AutomaticMigrationsEnabled = False
            AutomaticMigrationDataLossAllowed = False
            ContextKey = "MultiDb.Oracle.LabDbContext"
            MigrationsNamespace = "MultiDb.Oracle.Migrations"
            MigrationsDirectory = "Migrations"
            MigrationsAssembly = GetType(Configuration).Assembly
            TargetDatabase = New DbConnectionInfo("LabDb")
            CodeGenerator = New VisualBasicMigrationCodeGenerator()
            SetSqlGenerator("Oracle.ManagedDataAccess.Client", New Global.Oracle.ManagedDataAccess.EntityFramework.OracleMigrationSqlGenerator())
        End Sub
    End Class
End Namespace
