Aquí se generan las migraciones específicas de este motor. Ejecuta scaffold y vuelve a compilar antes de migrate. No copies migraciones ni snapshots desde otro motor.
