﻿Imports System.Data.Entity.Infrastructure
Imports System.Data.Entity.Migrations
Imports System.Data.Entity.Migrations.Design

Namespace MultiDb.SqlServer.Migrations
    Public Class Configuration
        Inherits DbMigrationsConfiguration(Of LabDbContext)

        Public Sub New()
            AutomaticMigrationsEnabled = False
            AutomaticMigrationDataLossAllowed = False
            ContextKey = "MultiDb.SqlServer.LabDbContext"
            MigrationsNamespace = "MultiDb.SqlServer.Migrations"
            MigrationsDirectory = "Migrations"
            MigrationsAssembly = GetType(Configuration).Assembly
            TargetDatabase = New DbConnectionInfo("LabDb")
            CodeGenerator = New VisualBasicMigrationCodeGenerator()
            SetSqlGenerator("System.Data.SqlClient", New System.Data.Entity.SqlServer.SqlServerMigrationSqlGenerator())
        End Sub
    End Class
End Namespace
