﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.Data.Entity

Namespace MultiDb.Model
    Public MustInherit Class BaseDbContext
        Inherits DbContext

        Protected Sub New(connectionName As String)
            MyBase.New("name=" & connectionName)
            Configuration.LazyLoadingEnabled = False
            Configuration.ProxyCreationEnabled = False
        End Sub

        Public Property Productos As DbSet(Of Producto)

        Protected Overrides Sub OnModelCreating(builder As DbModelBuilder)
            MyBase.OnModelCreating(builder)
            Dim entity = builder.Entity(Of Producto)()
            entity.ToTable("PRODUCTOS")
            entity.HasKey(Function(p) p.Id)
            entity.Property(Function(p) p.Id).HasColumnName("ID").HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity)
            entity.Property(Function(p) p.Nombre).HasColumnName("NOMBRE").IsRequired().HasMaxLength(100).IsUnicode(True)
        End Sub
    End Class
End Namespace
