﻿Namespace MultiDb.Model
    Public Class Producto
        Public Property Id As Integer
        Public Property Nombre As String
    End Class
End Namespace
