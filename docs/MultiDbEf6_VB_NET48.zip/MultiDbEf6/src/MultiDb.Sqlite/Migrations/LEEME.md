Scripts SQLite embebidos en el flujo de publicación: se copian junto al ejecutable y se ejecutan por orden con historial y SHA256. No son DbMigration de EF6.
