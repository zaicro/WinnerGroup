﻿Imports System.Data.Entity
Imports MultiDb.Model

Namespace MultiDb.Sqlite
    Public Class LabDbContext
        Inherits BaseDbContext

        Shared Sub New()
            ' El esquema se administra únicamente desde el migrador explícito.
            Database.SetInitializer(Of LabDbContext)(Nothing)
        End Sub

        Public Sub New()
            MyBase.New("LabDb")
        End Sub

        Protected Overrides Sub OnModelCreating(builder As DbModelBuilder)
            MyBase.OnModelCreating(builder)
            builder.Entity(Of Producto)().Property(Function(p) p.Id).HasColumnType("INTEGER")
            builder.Entity(Of Producto)().Property(Function(p) p.Nombre).HasColumnType("TEXT")
        End Sub
    End Class
End Namespace
