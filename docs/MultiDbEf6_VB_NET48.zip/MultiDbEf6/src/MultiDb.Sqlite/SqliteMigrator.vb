﻿Imports System
Imports System.Configuration
Imports System.Data.SQLite
Imports System.IO
Imports System.Linq
Imports System.Security.Cryptography
Imports System.Text

Namespace MultiDb.Sqlite
    Public Module SqliteMigrator
        Public Sub Migrate()
            Dim folder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Migrations")
            Dim files = Directory.GetFiles(folder, "*.sql").OrderBy(Function(p) Path.GetFileName(p), StringComparer.Ordinal).ToArray()
            If files.Length = 0 Then Throw New InvalidOperationException("No hay scripts SQLite en la salida.")
            Using cn As New SQLiteConnection(ConfigurationManager.ConnectionStrings("LabDb").ConnectionString)
                cn.Open()
                ' Un único proceso de despliegue debe aplicar las migraciones.
                Using tx = cn.BeginTransaction()
                    Execute(cn, tx, "CREATE TABLE IF NOT EXISTS __SchemaVersions (Version TEXT NOT NULL PRIMARY KEY, Sha256 TEXT NOT NULL, AppliedUtc TEXT NOT NULL)")
                    For Each scriptPath In files
                        Dim version = Path.GetFileName(scriptPath)
                        Dim sql = File.ReadAllText(scriptPath, Encoding.UTF8)
                        Dim checksum As String
                        Using hash = SHA256.Create()
                            checksum = BitConverter.ToString(hash.ComputeHash(Encoding.UTF8.GetBytes(sql))).Replace("-", "")
                        End Using
                        Using query As New SQLiteCommand("SELECT Sha256 FROM __SchemaVersions WHERE Version = @version", cn, tx)
                            query.Parameters.AddWithValue("@version", version)
                            Dim previous = query.ExecuteScalar()
                            If previous IsNot Nothing Then
                                If Not String.Equals(CStr(previous), checksum, StringComparison.Ordinal) Then Throw New InvalidOperationException("Se modificó un script aplicado: " & version)
                                Continue For
                            End If
                        End Using
                        Execute(cn, tx, sql)
                        Using insert As New SQLiteCommand("INSERT INTO __SchemaVersions(Version, Sha256, AppliedUtc) VALUES (@v,@h,@utc)", cn, tx)
                            insert.Parameters.AddWithValue("@v", version)
                            insert.Parameters.AddWithValue("@h", checksum)
                            insert.Parameters.AddWithValue("@utc", DateTime.UtcNow.ToString("O"))
                            insert.ExecuteNonQuery()
                        End Using
                        Console.WriteLine("Aplicada: " & version)
                    Next
                    tx.Commit()
                End Using
            End Using
        End Sub

        Private Sub Execute(cn As SQLiteConnection, tx As SQLiteTransaction, sql As String)
            Using command As New SQLiteCommand(sql, cn, tx)
                command.ExecuteNonQuery()
            End Using
        End Sub
    End Module
End Namespace
