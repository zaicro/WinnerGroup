﻿Imports System
Imports System.IO
Imports System.Linq
Imports MultiDb.Model

Namespace MultiDb.Sqlite
    Friend Module Program
        Public Function Main(args As String()) As Integer
            Try
                Dim data = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data")
                Directory.CreateDirectory(data)
                AppDomain.CurrentDomain.SetData("DataDirectory", data)
                If args.Length = 0 Then
                    Console.WriteLine("Comandos: migrate | demo")
                    Return 0
                End If
                Select Case args(0).ToLowerInvariant()
                    Case "migrate"
                        SqliteMigrator.Migrate()
                        Console.WriteLine("SQLite actualizado.")
                    Case "demo"
                        Using db As New LabDbContext()
                            If Not db.Productos.Any(Function(p) p.Nombre = "Producto de prueba") Then
                                db.Productos.Add(New Producto With {.Nombre = "Producto de prueba"})
                                db.SaveChanges()
                            End If
                            For Each p In db.Productos.AsNoTracking().OrderBy(Function(x) x.Id).Take(10).ToList()
                                Console.WriteLine(p.Id.ToString() & " | " & p.Nombre)
                            Next
                        End Using
                    Case Else
                        Throw New ArgumentException("SQLite usa migrate o demo. Su versionado es SQL explícito, no DbMigrator.")
                End Select
                Return 0
            Catch ex As Exception
                Console.Error.WriteLine(ex.ToString())
                Return 1
            End Try
        End Function
    End Module
End Namespace
