# Validación del paquete

## Comprobado

- Restauración real de paquetes NuGet para los cinco proyectos.
- Compilación de la solución completa para .NET Framework 4.8 con SDK 8.0.408 y ensamblados de referencia net48, en Linux.
- Resultado: **0 errores, 0 advertencias**.
- Compilan MultiDb.Model, MultiDb.SqlServer, MultiDb.PostgreSql, MultiDb.Oracle y MultiDb.Sqlite, incluyendo los tipos de los proveedores y sus generadores de SQL.
- XML válido en los cinco proyectos, cuatro App.config, NuGet.Config y Directory.Build.props.
- Ejecución del archivo 001_InitialCreate.sql con sqlite3 de Python: crea PRODUCTOS, genera ID, conserva texto Unicode y rechaza Nombre nulo o superior a 100 caracteres.

Comando de compilación:

```powershell
dotnet build MultiDbEf6.sln -c Debug -m:1 --nologo -v minimal
```

## Pendiente de validación en tu entorno

- Arranque de los ejecutables net48 en Windows.
- Conexión y migraciones reales contra SQL Server, PostgreSQL y Oracle. No había instancias ni credenciales disponibles.
- Generación real de la primera migración y compilación de su Designer/resx contra cada servidor. Los archivos se generan con scaffold en tu equipo; la solución incluye la configuración y el código que los genera.
- Ejecución completa del migrador y CRUD EF6 de SQLite con System.Data.SQLite y su dependencia nativa x64 en Windows. La prueba SQL con Python no prueba el proveedor .NET.
- Reejecución y checksum del migrador SQLite en Windows.

El ZIP contiene código fuente y documentación. No incluye paquetes restaurados, binarios de compilación ni bases de datos.
