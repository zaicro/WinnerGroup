﻿Imports System
Imports System.Data.Entity.Infrastructure
Imports System.Data.Entity.Migrations
Imports System.Data.Entity.Migrations.Design
Imports System.Data.Entity.Migrations.Infrastructure
Imports System.IO
Imports System.Linq
Imports System.Resources
Imports System.Text
Imports MultiDb.Model

Namespace MultiDb.Tools
    Public Module MigrationConsole
        Public Function Run(Of T As BaseDbContext)(args As String(), config As DbMigrationsConfiguration(Of T), factory As Func(Of T)) As Integer
            Try
                If args.Length = 0 Then
                    Console.WriteLine("Comandos: scaffold <Nombre> <directorio-proyecto> | pending | script <archivo.sql> | migrate | demo")
                    Return 0
                End If
                Select Case args(0).ToLowerInvariant()
                    Case "scaffold"
                        If args.Length <> 3 Then Throw New ArgumentException("scaffold <Nombre> <directorio-proyecto>")
                        If Not System.Text.RegularExpressions.Regex.IsMatch(args(1), "^[A-Za-z][A-Za-z0-9_]*$") Then Throw New ArgumentException("Usa un nombre VB simple, por ejemplo InitialCreate.")
                        Dim project = Path.GetFullPath(args(2))
                        If Not Directory.Exists(project) OrElse Not Directory.EnumerateFiles(project, "*.vbproj").Any() Then Throw New ArgumentException("El destino debe contener el .vbproj de este motor.")
                        If Not File.Exists(Path.Combine(project, GetType(T).Assembly.GetName().Name & ".vbproj")) Then Throw New ArgumentException("El proyecto destino no corresponde a este ejecutable.")
                        Dim folder = Path.Combine(project, "Migrations")
                        Directory.CreateDirectory(folder)
                        ' ResourceManager(GetType(Nombre)) busca Namespace.Nombre.resources.
                        ' Por eso el resx usa el nombre de clase, sin timestamp.
                        Dim resx = Path.Combine(folder, args(1) & ".resx")
                        If File.Exists(resx) Then Throw New InvalidOperationException("Ya existe una migración con ese nombre.")
                        Dim scaffold = New MigrationScaffolder(config).Scaffold(args(1))
                        File.WriteAllText(Path.Combine(folder, scaffold.MigrationId & ".vb"), scaffold.UserCode, Encoding.UTF8)
                        File.WriteAllText(Path.Combine(folder, scaffold.MigrationId & ".Designer.vb"), scaffold.DesignerCode, Encoding.UTF8)
                        Using writer As New ResXResourceWriter(resx)
                            For Each item In scaffold.Resources
                                writer.AddResource(item.Key, item.Value)
                            Next
                        End Using
                        Console.WriteLine("Generada: " & scaffold.MigrationId & ". Revisa Up/Down y recompila antes de migrate.")
                    Case "pending", "script", "migrate"
                        Dim migrator As New DbMigrator(config)
                        If Not migrator.GetLocalMigrations().Any() Then Throw New InvalidOperationException("No hay migraciones compiladas. Ejecuta scaffold InitialCreate y recompila.")
                        If args(0).Equals("pending", StringComparison.OrdinalIgnoreCase) Then
                            For Each migration In migrator.GetPendingMigrations()
                                Console.WriteLine(migration)
                            Next
                        ElseIf args(0).Equals("script", StringComparison.OrdinalIgnoreCase) Then
                            If args.Length <> 2 Then Throw New ArgumentException("script <archivo.sql>")
                            ' Script desde 0: revisar para una base vacía; no aplicar a una base ya migrada.
                            Dim sql = New MigratorScriptingDecorator(migrator).ScriptUpdate("0", Nothing)
                            File.WriteAllText(Path.GetFullPath(args(1)), sql, Encoding.UTF8)
                            Console.WriteLine("SQL generado desde 0: " & Path.GetFullPath(args(1)))
                        Else
                            migrator.Update()
                            Console.WriteLine("Migraciones aplicadas.")
                        End If
                    Case "demo"
                        Using db = factory()
                            If Not db.Productos.Any(Function(p) p.Nombre = "Producto de prueba") Then
                                db.Productos.Add(New Producto With {.Nombre = "Producto de prueba"})
                                db.SaveChanges()
                            End If
                            For Each p In db.Productos.AsNoTracking().OrderBy(Function(x) x.Id).Take(10).ToList()
                                Console.WriteLine(p.Id.ToString() & " | " & p.Nombre)
                            Next
                        End Using
                    Case Else
                        Throw New ArgumentException("Comando desconocido.")
                End Select
                Return 0
            Catch ex As Exception
                Console.Error.WriteLine(ex.ToString())
                Return 1
            End Try
        End Function
    End Module
End Namespace
