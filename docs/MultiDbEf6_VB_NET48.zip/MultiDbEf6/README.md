# VB.NET .NET Framework 4.8 + EF6: varios motores

Laboratorio para comparar **DbContext, App.config y migraciones** con una entidad `Producto(Id, Nombre)` y la tabla `PRODUCTOS`. EF es **6.5.1**, no EF Core. Los proyectos usan formato SDK, pero compilan para **net48**.

## 1. Qué contiene

| Proyecto | Responsabilidad |
|---|---|
| MultiDb.Model | Producto y BaseDbContext con el mapeo común |
| MultiDb.SqlServer | Contexto, App.config, configuración de migraciones y consola SQL Server |
| MultiDb.PostgreSql | Lo mismo, con Npgsql y esquema public |
| MultiDb.Oracle | Lo mismo, con ODP.NET y esquema del usuario de conexión |
| MultiDb.Sqlite | Contexto EF6, App.config y migrador SQL con historial propio |
| Shared/MigrationConsole.vb | Consola compartida, compilada dentro de cada ejecutable EF6 |

Los ejecutables separados hacen visible qué depende de cada proveedor. El código de entidad y mapeo básico se comparte; cada motor mantiene su propio modelo compilado, snapshots e historial. No se reutiliza un archivo de migración entre motores.

## 2. Diferencias que no debes ocultar

| Motor | Qué se puede crear | Versionado incluido |
|---|---|---|
| SQL Server | Base y tablas en una instancia existente, si el login tiene permisos | Migraciones explícitas EF6 |
| PostgreSQL | Base y tablas en un servidor existente, si el rol tiene CREATEDB; también puedes provisionar la base antes | Migraciones explícitas EF6 |
| Oracle | Tablas, secuencias y otros objetos en un usuario/esquema previamente provisionado | Migraciones explícitas EF6 |
| SQLite | Archivo local y tablas | Scripts SQL transaccionales; no son migraciones EF6 |

EF no instala servidores. En Oracle, crear una instancia/PDB/usuario es un paso administrativo separado. En SQLite, System.Data.SQLite 1.0.119 no aporta el generador de migraciones EF6: aquí usamos EF6 para CRUD y un pequeño migrador SQL para el esquema. Existen extensiones y proveedores alternativos; no se incluyen ni se asume que tengan las mismas capacidades.

## 3. Requisitos y primer recorrido

Windows x64; Visual Studio 2022 con desarrollo .NET y SDK de .NET instalado, o Developer PowerShell con `dotnet`; .NET Framework 4.8 Runtime. Se referencia el paquete de ensamblados net48 para compilación. Los procesos de ejemplo son x64 por SQLite.Interop.dll.

1. Abre `MultiDbEf6.sln`.
2. Revisa `src/MultiDb.<Motor>/App.config`: cambia host, servicio, base, usuario y contraseña.
3. Empieza por SQL Server LocalDB o SQLite.
4. Desde PowerShell, en la carpeta que contiene la solución:

```powershell
dotnet build .\MultiDbEf6.sln -c Debug
```

Los tres proyectos EF6 traen `Migrations/Configuration.vb`; la primera migración se genera contra tu proveedor y entorno al ejecutar `scaffold`. Se producen `.vb`, `.Designer.vb` y `.resx` con el snapshot real. Después hay que **recompilar**, porque DbMigrator descubre migraciones compiladas dentro del assembly.

La generación puede abrir una conexión para conocer la versión del servidor y consultar el historial. Debe existir un servidor accesible; Oracle necesita además el usuario/esquema preparado. Los comandos retornan 1 si fallan.

## 4. SQL Server

La conexión predeterminada usa `(localdb)\MSSQLLocalDB`, base `MultiDbEf6Lab` e identidad Windows. Instala LocalDB o cambia la cadena por tu instancia.

```powershell
$project = '.\src\MultiDb.SqlServer'
$exe = "$project\bin\Debug\MultiDb.SqlServer.exe"
& $exe scaffold InitialCreate $project
if ($LASTEXITCODE -ne 0) { throw 'Falló scaffold' }
dotnet build "$project\MultiDb.SqlServer.vbproj" -c Debug
if ($LASTEXITCODE -ne 0) { throw 'Falló build' }
& $exe pending
& $exe script .\sqlserver-desde-cero.sql
& $exe migrate
& $exe demo
```

El archivo SQL generado sirve para inspeccionar una creación **desde cero**. No lo ejecutes sobre una base ya migrada. `migrate` consulta el historial y aplica solo lo pendiente.

Puntos a revisar: `LabDbContext.vb`, `App.config`, `Migrations/Configuration.vb`. Esquema `dbo`, proveedor `System.Data.SqlClient`, generador `SqlServerMigrationSqlGenerator`.

## 5. PostgreSQL

Configura `Host`, `Database`, `Username` y `Password`. Npgsql puede crear la base si el rol tiene permisos; si no, un administrador debe provisionarla con el propietario adecuado. Para este laboratorio es más simple crear una base vacía antes de generar la migración.

Ejemplo administrativo, fuera de EF y conectado a una base de mantenimiento:

```sql
CREATE DATABASE multidb_ef6_lab OWNER postgres;
```

```powershell
$project = '.\src\MultiDb.PostgreSql'
dotnet build "$project\MultiDb.PostgreSql.vbproj" -c Debug
$exe = "$project\bin\Debug\MultiDb.PostgreSql.exe"
& $exe scaffold InitialCreate $project
if ($LASTEXITCODE -ne 0) { throw 'Falló scaffold' }
dotnet build "$project\MultiDb.PostgreSql.vbproj" -c Debug
if ($LASTEXITCODE -ne 0) { throw 'Falló build' }
& $exe script .\postgres-desde-cero.sql
& $exe migrate
& $exe demo
```

Esquema `public`; proveedor `Npgsql`; `EntityFramework6.Npgsql` 6.4.3 y driver Npgsql 4.1.14. No sustituyas el driver por una versión mayor arbitraria: el proveedor EF6 usa esta familia de API. Son versiones fijadas para el laboratorio, no una recomendación automática para producción.

Los nombres en mayúsculas se conservan mediante identificadores entre comillas del proveedor. Una consulta manual sería `SELECT * FROM public."PRODUCTOS"`.

## 6. Oracle

Usa un entorno Oracle de laboratorio (por ejemplo Oracle Database Free con servicio FREEPDB1) y un usuario exclusivo para la prueba. Ejecuta como administrador **dentro de la PDB destino**, ajustando contraseña y tablespace:

```sql
CREATE USER EF6LAB IDENTIFIED BY "Replace_This_Lab_Password";
GRANT CREATE SESSION, CREATE TABLE, CREATE SEQUENCE, CREATE TRIGGER TO EF6LAB;
ALTER USER EF6LAB QUOTA 100M ON USERS;
```

Configura la misma contraseña en App.config. El servicio `localhost:1521/FREEPDB1` es solo un ejemplo. Se asumen usuarios Oracle normales creados sin comillas; el contexto convierte `User Id` a mayúsculas para `HasDefaultSchema`. No se contemplan usuarios con identificadores entrecomillados sensibles a mayúsculas. El esquema queda fijado en el snapshot generado: cambiar luego de usuario/esquema requiere planificar las migraciones; no basta con editar la conexión.

```powershell
$project = '.\src\MultiDb.Oracle'
dotnet build "$project\MultiDb.Oracle.vbproj" -c Debug
$exe = "$project\bin\Debug\MultiDb.Oracle.exe"
& $exe scaffold InitialCreate $project
if ($LASTEXITCODE -ne 0) { throw 'Falló scaffold' }
dotnet build "$project\MultiDb.Oracle.vbproj" -c Debug
if ($LASTEXITCODE -ne 0) { throw 'Falló build' }
& $exe script .\oracle-desde-cero.sql
& $exe migrate
& $exe demo
```

ODP.NET crea objetos dentro de EF6LAB; no crea la instancia ni la PDB. El mapeo `Nombre` se limita a 100 caracteres, evitando un NCLOB por convención. El proveedor decide el SQL de identidad y las secuencias/triggers que correspondan a su versión de servidor. Revisa el SQL antes de aplicarlo. El DDL de Oracle puede hacer commits implícitos: no asumas rollback global si falla una migración.

## 7. SQLite

```powershell
$project = '.\src\MultiDb.Sqlite'
dotnet build "$project\MultiDb.Sqlite.vbproj" -c Debug
if ($LASTEXITCODE -ne 0) { throw 'Falló build' }
$exe = "$project\bin\Debug\MultiDb.Sqlite.exe"
& $exe migrate
& $exe demo
& $exe migrate
```

Se crea `bin\Debug\Data\lab.db`. El segundo `migrate` omite el script ya aplicado. No necesita servidor ni credenciales.

- `LabDbContext`: CRUD EF6 con mapeos `INTEGER` y `TEXT`.
- `SqliteMigrator`: conexión ADO.NET, transacción, ejecución ordenada y tabla `__SchemaVersions`.
- `Migrations/001_InitialCreate.sql`: creación de PRODUCTOS.
- Se guarda SHA256 por script; si editas uno ya aplicado, el migrador rechaza la ejecución.
- Para ampliar el esquema, añade `002_...sql`, vuelve a compilar y ejecuta `migrate`. Mantén archivos anteriores. Usa prefijos numéricos de ancho fijo y versiones crecientes.
- El migrador de ejemplo asume scripts de confianza y una sola instancia de despliegue. No implementa downgrade ni comprobación de deriva del esquema.

No copies solo el EXE: distribuye la salida completa, incluidas DLL, configuración, carpeta Migrations y dependencias nativas x64 de SQLite. `DllNotFoundException` sobre SQLite.Interop.dll suele indicar un despliegue incompleto o arquitectura incorrecta.

## 8. El núcleo del migrate EF6

En cada proyecto EF6 existe una configuración propia:

```vb
Public Class Configuration
    Inherits DbMigrationsConfiguration(Of LabDbContext)

    Public Sub New()
        AutomaticMigrationsEnabled = False
        AutomaticMigrationDataLossAllowed = False
        ContextKey = "MultiDb.SqlServer.LabDbContext"
        MigrationsNamespace = "MultiDb.SqlServer.Migrations"
        MigrationsAssembly = GetType(Configuration).Assembly
        TargetDatabase = New DbConnectionInfo("LabDb")
        CodeGenerator = New VisualBasicMigrationCodeGenerator()
        SetSqlGenerator("System.Data.SqlClient", New SqlServerMigrationSqlGenerator())
    End Sub
End Class
```

La aplicación de las migraciones compiladas es:

```vb
Dim migrator As New DbMigrator(New Migrations.Configuration())
migrator.Update()
```

La consola `scaffold` usa `MigrationScaffolder`, una API de EF6, para generar el código VB y los metadatos. Evita depender de las particularidades de integración de Package Manager Console con proyectos SDK. No activa migraciones automáticas ni inicializadores que borren bases de datos.

El `.resx` se guarda con el nombre de la clase de migración y el proyecto le asigna `LogicalName = Namespace.Nombre.resources`; así coincide con `ResourceManager(GetType(Nombre))` del diseñador generado. No borres los `.Designer.vb` ni `.resx`: contienen el modelo que EF utiliza para calcular diferencias.

## 9. Cómo añadir un segundo cambio

1. Añade una propiedad al modelo compartido y su mapeo.
2. Compila la solución.
3. Ejecuta `scaffold AgregarCampo <directorio-proyecto>` en SQL Server, PostgreSQL y Oracle por separado.
4. Revisa los tres `Up`/`Down` y el SQL específico. **No generes una segunda migración con el mismo nombre** ni omitas compilar las anteriores.
5. Recompila y ejecuta `migrate` en cada motor.
6. Para SQLite escribe `002_AgregarCampo.sql`, compila y ejecuta su `migrate`.

`ContextKey` distingue historias; no convierte el SQL entre motores. Cambiar solo el providerName y conservar el snapshot de otro motor no es el flujo de este proyecto. Tampoco traduzcas procedimientos almacenados o SQL escrito a mano suponiendo que EF lo hará por ti.

## 10. Configuración y credenciales

EF lee el **config del ejecutable de inicio**, no el de una biblioteca referenciada. Por eso cada consola tiene su App.config. Al llevar estos contextos a una API o WinForms, pasa la configuración necesaria al Web.config/App.config de esa aplicación.

Los secretos incluidos son marcadores `CHANGE_ME`. Para uso real puedes extraer `<connectionStrings>` a un archivo local mediante `configSource="Connections.local.config"` y no versionarlo; el archivo externo debe contener el elemento `<connectionStrings>...</connectionStrings>` y copiarse al directorio del ejecutable. Sacarlo del repositorio no cifra el archivo. Evita incluir una credencial con permisos de migración dentro del cliente de escritorio distribuido; ejecuta el despliegue con una identidad controlada.

## 11. Validación y límites

Consulta `VALIDACION.md` para el alcance real de las verificaciones efectuadas al generar este paquete. No se da por probado un motor por haber revisado únicamente su configuración. Este proyecto cubre SQL Server, PostgreSQL, Oracle y SQLite; agregar otro motor requiere comprobar un proveedor **EF6** compatible con net48 y sus capacidades de migración.

## Fuentes primarias

- EF6 MigrationScaffolder: https://learn.microsoft.com/en-us/dotnet/api/system.data.entity.migrations.design.migrationscaffolder
- EF6 migraciones: https://learn.microsoft.com/en-us/ef/ef6/modeling/code-first/migrations/
- Npgsql EF6: https://www.npgsql.org/ef6/
- Oracle configuración Code First: https://docs.oracle.com/en/database/oracle/oracle-database/26/odpnt/InstallEntityConfig.html
- Oracle Code First y migraciones: https://docs.oracle.com/en/database/oracle/oracle-database/26/odpnt/entityCodeFirst.html
- SQLite petición de soporte EF6 migrations: https://system.data.sqlite.org/home/info/6b5ef4ff7a
- SQLite distribución: https://system.data.sqlite.org/home/doc/trunk/www/faq.wiki
